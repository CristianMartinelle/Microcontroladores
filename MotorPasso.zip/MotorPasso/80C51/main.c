#include <8051.h>
#define TEMPO 15535
#define SEQUENCIA 0x70

void Atraso() {
    unsigned char R1 = 5;

    while (R1 > 0) {
        TR1 = 0;  // Para o Timer 1
        TF1 = 0;  // Zera a flag de estouro do Timer
        TH1 = (unsigned char)(TEMPO >> 8);  // Carrega parte alta do Timer
        TL1 = (unsigned char)TEMPO;          // Carrega parte baixa do Timer
        TR1 = 1;                             // Liga o Timer

        while (!TF1);  // Aguarda at� que o Timer estoure
        R1--;          // Decrementa o contador
    }

    TR1 = 0;  // Para o Timer
    TF1 = 0;  // Zera a flag de estouro do Timer
}

void main() {
    unsigned char R0;

    TMOD = 0x10;        // Timer 1 no modo 1 (contagem em 16 bits)
    DPTR = (unsigned int)SEQUENCIA;  // Carrega o endere�o do apontador

SEQUENCIA:
	
Rotacao:
    R0 = 0;            // Zera o contador

Volta:
    P1 = *(char __code *)(DPTR + R0);  // L� a palavra a ser enviada ao motor
    Atraso();                           // Chama a sub-rotina de atraso
    R0++;                               // Incrementa o contador

    if (R0 < 8) goto Volta;  // Se menor que 8, continua a sequ�ncia

    goto Rotacao;  // Desvio para rota��o
}
