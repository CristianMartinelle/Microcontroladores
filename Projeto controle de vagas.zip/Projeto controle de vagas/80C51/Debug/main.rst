                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler 
                                      3 ; Version 4.3.0 #14184 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module main
                                      6 	.optsdcc -mmcs51 --model-small
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _main
                                     12 	.globl _int1
                                     13 	.globl _int0
                                     14 	.globl _CY
                                     15 	.globl _AC
                                     16 	.globl _F0
                                     17 	.globl _RS1
                                     18 	.globl _RS0
                                     19 	.globl _OV
                                     20 	.globl _FL
                                     21 	.globl _P
                                     22 	.globl _TF2
                                     23 	.globl _EXF2
                                     24 	.globl _RCLK
                                     25 	.globl _TCLK
                                     26 	.globl _EXEN2
                                     27 	.globl _TR2
                                     28 	.globl _C_T2
                                     29 	.globl _CP_RL2
                                     30 	.globl _T2CON_7
                                     31 	.globl _T2CON_6
                                     32 	.globl _T2CON_5
                                     33 	.globl _T2CON_4
                                     34 	.globl _T2CON_3
                                     35 	.globl _T2CON_2
                                     36 	.globl _T2CON_1
                                     37 	.globl _T2CON_0
                                     38 	.globl _PT2
                                     39 	.globl _PS
                                     40 	.globl _PT1
                                     41 	.globl _PX1
                                     42 	.globl _PT0
                                     43 	.globl _PX0
                                     44 	.globl _RD
                                     45 	.globl _WR
                                     46 	.globl _T1
                                     47 	.globl _T0
                                     48 	.globl _INT1
                                     49 	.globl _INT0
                                     50 	.globl _TXD
                                     51 	.globl _RXD
                                     52 	.globl _P3_7
                                     53 	.globl _P3_6
                                     54 	.globl _P3_5
                                     55 	.globl _P3_4
                                     56 	.globl _P3_3
                                     57 	.globl _P3_2
                                     58 	.globl _P3_1
                                     59 	.globl _P3_0
                                     60 	.globl _EA
                                     61 	.globl _ET2
                                     62 	.globl _ES
                                     63 	.globl _ET1
                                     64 	.globl _EX1
                                     65 	.globl _ET0
                                     66 	.globl _EX0
                                     67 	.globl _P2_7
                                     68 	.globl _P2_6
                                     69 	.globl _P2_5
                                     70 	.globl _P2_4
                                     71 	.globl _P2_3
                                     72 	.globl _P2_2
                                     73 	.globl _P2_1
                                     74 	.globl _P2_0
                                     75 	.globl _SM0
                                     76 	.globl _SM1
                                     77 	.globl _SM2
                                     78 	.globl _REN
                                     79 	.globl _TB8
                                     80 	.globl _RB8
                                     81 	.globl _TI
                                     82 	.globl _RI
                                     83 	.globl _T2EX
                                     84 	.globl _T2
                                     85 	.globl _P1_7
                                     86 	.globl _P1_6
                                     87 	.globl _P1_5
                                     88 	.globl _P1_4
                                     89 	.globl _P1_3
                                     90 	.globl _P1_2
                                     91 	.globl _P1_1
                                     92 	.globl _P1_0
                                     93 	.globl _TF1
                                     94 	.globl _TR1
                                     95 	.globl _TF0
                                     96 	.globl _TR0
                                     97 	.globl _IE1
                                     98 	.globl _IT1
                                     99 	.globl _IE0
                                    100 	.globl _IT0
                                    101 	.globl _P0_7
                                    102 	.globl _P0_6
                                    103 	.globl _P0_5
                                    104 	.globl _P0_4
                                    105 	.globl _P0_3
                                    106 	.globl _P0_2
                                    107 	.globl _P0_1
                                    108 	.globl _P0_0
                                    109 	.globl _B
                                    110 	.globl _A
                                    111 	.globl _ACC
                                    112 	.globl _PSW
                                    113 	.globl _TH2
                                    114 	.globl _TL2
                                    115 	.globl _RCAP2H
                                    116 	.globl _RCAP2L
                                    117 	.globl _T2MOD
                                    118 	.globl _T2CON
                                    119 	.globl _IP
                                    120 	.globl _P3
                                    121 	.globl _IE
                                    122 	.globl _P2
                                    123 	.globl _SBUF
                                    124 	.globl _SCON
                                    125 	.globl _P1
                                    126 	.globl _TH1
                                    127 	.globl _TH0
                                    128 	.globl _TL1
                                    129 	.globl _TL0
                                    130 	.globl _TMOD
                                    131 	.globl _TCON
                                    132 	.globl _PCON
                                    133 	.globl _DPH
                                    134 	.globl _DPL
                                    135 	.globl _SP
                                    136 	.globl _P0
                                    137 	.globl _cont
                                    138 ;--------------------------------------------------------
                                    139 ; special function registers
                                    140 ;--------------------------------------------------------
                                    141 	.area RSEG    (ABS,DATA)
      000000                        142 	.org 0x0000
                           000080   143 G$P0$0_0$0 == 0x0080
                           000080   144 _P0	=	0x0080
                           000081   145 G$SP$0_0$0 == 0x0081
                           000081   146 _SP	=	0x0081
                           000082   147 G$DPL$0_0$0 == 0x0082
                           000082   148 _DPL	=	0x0082
                           000083   149 G$DPH$0_0$0 == 0x0083
                           000083   150 _DPH	=	0x0083
                           000087   151 G$PCON$0_0$0 == 0x0087
                           000087   152 _PCON	=	0x0087
                           000088   153 G$TCON$0_0$0 == 0x0088
                           000088   154 _TCON	=	0x0088
                           000089   155 G$TMOD$0_0$0 == 0x0089
                           000089   156 _TMOD	=	0x0089
                           00008A   157 G$TL0$0_0$0 == 0x008a
                           00008A   158 _TL0	=	0x008a
                           00008B   159 G$TL1$0_0$0 == 0x008b
                           00008B   160 _TL1	=	0x008b
                           00008C   161 G$TH0$0_0$0 == 0x008c
                           00008C   162 _TH0	=	0x008c
                           00008D   163 G$TH1$0_0$0 == 0x008d
                           00008D   164 _TH1	=	0x008d
                           000090   165 G$P1$0_0$0 == 0x0090
                           000090   166 _P1	=	0x0090
                           000098   167 G$SCON$0_0$0 == 0x0098
                           000098   168 _SCON	=	0x0098
                           000099   169 G$SBUF$0_0$0 == 0x0099
                           000099   170 _SBUF	=	0x0099
                           0000A0   171 G$P2$0_0$0 == 0x00a0
                           0000A0   172 _P2	=	0x00a0
                           0000A8   173 G$IE$0_0$0 == 0x00a8
                           0000A8   174 _IE	=	0x00a8
                           0000B0   175 G$P3$0_0$0 == 0x00b0
                           0000B0   176 _P3	=	0x00b0
                           0000B8   177 G$IP$0_0$0 == 0x00b8
                           0000B8   178 _IP	=	0x00b8
                           0000C8   179 G$T2CON$0_0$0 == 0x00c8
                           0000C8   180 _T2CON	=	0x00c8
                           0000C9   181 G$T2MOD$0_0$0 == 0x00c9
                           0000C9   182 _T2MOD	=	0x00c9
                           0000CA   183 G$RCAP2L$0_0$0 == 0x00ca
                           0000CA   184 _RCAP2L	=	0x00ca
                           0000CB   185 G$RCAP2H$0_0$0 == 0x00cb
                           0000CB   186 _RCAP2H	=	0x00cb
                           0000CC   187 G$TL2$0_0$0 == 0x00cc
                           0000CC   188 _TL2	=	0x00cc
                           0000CD   189 G$TH2$0_0$0 == 0x00cd
                           0000CD   190 _TH2	=	0x00cd
                           0000D0   191 G$PSW$0_0$0 == 0x00d0
                           0000D0   192 _PSW	=	0x00d0
                           0000E0   193 G$ACC$0_0$0 == 0x00e0
                           0000E0   194 _ACC	=	0x00e0
                           0000E0   195 G$A$0_0$0 == 0x00e0
                           0000E0   196 _A	=	0x00e0
                           0000F0   197 G$B$0_0$0 == 0x00f0
                           0000F0   198 _B	=	0x00f0
                                    199 ;--------------------------------------------------------
                                    200 ; special function bits
                                    201 ;--------------------------------------------------------
                                    202 	.area RSEG    (ABS,DATA)
      000000                        203 	.org 0x0000
                           000080   204 G$P0_0$0_0$0 == 0x0080
                           000080   205 _P0_0	=	0x0080
                           000081   206 G$P0_1$0_0$0 == 0x0081
                           000081   207 _P0_1	=	0x0081
                           000082   208 G$P0_2$0_0$0 == 0x0082
                           000082   209 _P0_2	=	0x0082
                           000083   210 G$P0_3$0_0$0 == 0x0083
                           000083   211 _P0_3	=	0x0083
                           000084   212 G$P0_4$0_0$0 == 0x0084
                           000084   213 _P0_4	=	0x0084
                           000085   214 G$P0_5$0_0$0 == 0x0085
                           000085   215 _P0_5	=	0x0085
                           000086   216 G$P0_6$0_0$0 == 0x0086
                           000086   217 _P0_6	=	0x0086
                           000087   218 G$P0_7$0_0$0 == 0x0087
                           000087   219 _P0_7	=	0x0087
                           000088   220 G$IT0$0_0$0 == 0x0088
                           000088   221 _IT0	=	0x0088
                           000089   222 G$IE0$0_0$0 == 0x0089
                           000089   223 _IE0	=	0x0089
                           00008A   224 G$IT1$0_0$0 == 0x008a
                           00008A   225 _IT1	=	0x008a
                           00008B   226 G$IE1$0_0$0 == 0x008b
                           00008B   227 _IE1	=	0x008b
                           00008C   228 G$TR0$0_0$0 == 0x008c
                           00008C   229 _TR0	=	0x008c
                           00008D   230 G$TF0$0_0$0 == 0x008d
                           00008D   231 _TF0	=	0x008d
                           00008E   232 G$TR1$0_0$0 == 0x008e
                           00008E   233 _TR1	=	0x008e
                           00008F   234 G$TF1$0_0$0 == 0x008f
                           00008F   235 _TF1	=	0x008f
                           000090   236 G$P1_0$0_0$0 == 0x0090
                           000090   237 _P1_0	=	0x0090
                           000091   238 G$P1_1$0_0$0 == 0x0091
                           000091   239 _P1_1	=	0x0091
                           000092   240 G$P1_2$0_0$0 == 0x0092
                           000092   241 _P1_2	=	0x0092
                           000093   242 G$P1_3$0_0$0 == 0x0093
                           000093   243 _P1_3	=	0x0093
                           000094   244 G$P1_4$0_0$0 == 0x0094
                           000094   245 _P1_4	=	0x0094
                           000095   246 G$P1_5$0_0$0 == 0x0095
                           000095   247 _P1_5	=	0x0095
                           000096   248 G$P1_6$0_0$0 == 0x0096
                           000096   249 _P1_6	=	0x0096
                           000097   250 G$P1_7$0_0$0 == 0x0097
                           000097   251 _P1_7	=	0x0097
                           000090   252 G$T2$0_0$0 == 0x0090
                           000090   253 _T2	=	0x0090
                           000091   254 G$T2EX$0_0$0 == 0x0091
                           000091   255 _T2EX	=	0x0091
                           000098   256 G$RI$0_0$0 == 0x0098
                           000098   257 _RI	=	0x0098
                           000099   258 G$TI$0_0$0 == 0x0099
                           000099   259 _TI	=	0x0099
                           00009A   260 G$RB8$0_0$0 == 0x009a
                           00009A   261 _RB8	=	0x009a
                           00009B   262 G$TB8$0_0$0 == 0x009b
                           00009B   263 _TB8	=	0x009b
                           00009C   264 G$REN$0_0$0 == 0x009c
                           00009C   265 _REN	=	0x009c
                           00009D   266 G$SM2$0_0$0 == 0x009d
                           00009D   267 _SM2	=	0x009d
                           00009E   268 G$SM1$0_0$0 == 0x009e
                           00009E   269 _SM1	=	0x009e
                           00009F   270 G$SM0$0_0$0 == 0x009f
                           00009F   271 _SM0	=	0x009f
                           0000A0   272 G$P2_0$0_0$0 == 0x00a0
                           0000A0   273 _P2_0	=	0x00a0
                           0000A1   274 G$P2_1$0_0$0 == 0x00a1
                           0000A1   275 _P2_1	=	0x00a1
                           0000A2   276 G$P2_2$0_0$0 == 0x00a2
                           0000A2   277 _P2_2	=	0x00a2
                           0000A3   278 G$P2_3$0_0$0 == 0x00a3
                           0000A3   279 _P2_3	=	0x00a3
                           0000A4   280 G$P2_4$0_0$0 == 0x00a4
                           0000A4   281 _P2_4	=	0x00a4
                           0000A5   282 G$P2_5$0_0$0 == 0x00a5
                           0000A5   283 _P2_5	=	0x00a5
                           0000A6   284 G$P2_6$0_0$0 == 0x00a6
                           0000A6   285 _P2_6	=	0x00a6
                           0000A7   286 G$P2_7$0_0$0 == 0x00a7
                           0000A7   287 _P2_7	=	0x00a7
                           0000A8   288 G$EX0$0_0$0 == 0x00a8
                           0000A8   289 _EX0	=	0x00a8
                           0000A9   290 G$ET0$0_0$0 == 0x00a9
                           0000A9   291 _ET0	=	0x00a9
                           0000AA   292 G$EX1$0_0$0 == 0x00aa
                           0000AA   293 _EX1	=	0x00aa
                           0000AB   294 G$ET1$0_0$0 == 0x00ab
                           0000AB   295 _ET1	=	0x00ab
                           0000AC   296 G$ES$0_0$0 == 0x00ac
                           0000AC   297 _ES	=	0x00ac
                           0000AD   298 G$ET2$0_0$0 == 0x00ad
                           0000AD   299 _ET2	=	0x00ad
                           0000AF   300 G$EA$0_0$0 == 0x00af
                           0000AF   301 _EA	=	0x00af
                           0000B0   302 G$P3_0$0_0$0 == 0x00b0
                           0000B0   303 _P3_0	=	0x00b0
                           0000B1   304 G$P3_1$0_0$0 == 0x00b1
                           0000B1   305 _P3_1	=	0x00b1
                           0000B2   306 G$P3_2$0_0$0 == 0x00b2
                           0000B2   307 _P3_2	=	0x00b2
                           0000B3   308 G$P3_3$0_0$0 == 0x00b3
                           0000B3   309 _P3_3	=	0x00b3
                           0000B4   310 G$P3_4$0_0$0 == 0x00b4
                           0000B4   311 _P3_4	=	0x00b4
                           0000B5   312 G$P3_5$0_0$0 == 0x00b5
                           0000B5   313 _P3_5	=	0x00b5
                           0000B6   314 G$P3_6$0_0$0 == 0x00b6
                           0000B6   315 _P3_6	=	0x00b6
                           0000B7   316 G$P3_7$0_0$0 == 0x00b7
                           0000B7   317 _P3_7	=	0x00b7
                           0000B0   318 G$RXD$0_0$0 == 0x00b0
                           0000B0   319 _RXD	=	0x00b0
                           0000B1   320 G$TXD$0_0$0 == 0x00b1
                           0000B1   321 _TXD	=	0x00b1
                           0000B2   322 G$INT0$0_0$0 == 0x00b2
                           0000B2   323 _INT0	=	0x00b2
                           0000B3   324 G$INT1$0_0$0 == 0x00b3
                           0000B3   325 _INT1	=	0x00b3
                           0000B4   326 G$T0$0_0$0 == 0x00b4
                           0000B4   327 _T0	=	0x00b4
                           0000B5   328 G$T1$0_0$0 == 0x00b5
                           0000B5   329 _T1	=	0x00b5
                           0000B6   330 G$WR$0_0$0 == 0x00b6
                           0000B6   331 _WR	=	0x00b6
                           0000B7   332 G$RD$0_0$0 == 0x00b7
                           0000B7   333 _RD	=	0x00b7
                           0000B8   334 G$PX0$0_0$0 == 0x00b8
                           0000B8   335 _PX0	=	0x00b8
                           0000B9   336 G$PT0$0_0$0 == 0x00b9
                           0000B9   337 _PT0	=	0x00b9
                           0000BA   338 G$PX1$0_0$0 == 0x00ba
                           0000BA   339 _PX1	=	0x00ba
                           0000BB   340 G$PT1$0_0$0 == 0x00bb
                           0000BB   341 _PT1	=	0x00bb
                           0000BC   342 G$PS$0_0$0 == 0x00bc
                           0000BC   343 _PS	=	0x00bc
                           0000BD   344 G$PT2$0_0$0 == 0x00bd
                           0000BD   345 _PT2	=	0x00bd
                           0000C8   346 G$T2CON_0$0_0$0 == 0x00c8
                           0000C8   347 _T2CON_0	=	0x00c8
                           0000C9   348 G$T2CON_1$0_0$0 == 0x00c9
                           0000C9   349 _T2CON_1	=	0x00c9
                           0000CA   350 G$T2CON_2$0_0$0 == 0x00ca
                           0000CA   351 _T2CON_2	=	0x00ca
                           0000CB   352 G$T2CON_3$0_0$0 == 0x00cb
                           0000CB   353 _T2CON_3	=	0x00cb
                           0000CC   354 G$T2CON_4$0_0$0 == 0x00cc
                           0000CC   355 _T2CON_4	=	0x00cc
                           0000CD   356 G$T2CON_5$0_0$0 == 0x00cd
                           0000CD   357 _T2CON_5	=	0x00cd
                           0000CE   358 G$T2CON_6$0_0$0 == 0x00ce
                           0000CE   359 _T2CON_6	=	0x00ce
                           0000CF   360 G$T2CON_7$0_0$0 == 0x00cf
                           0000CF   361 _T2CON_7	=	0x00cf
                           0000C8   362 G$CP_RL2$0_0$0 == 0x00c8
                           0000C8   363 _CP_RL2	=	0x00c8
                           0000C9   364 G$C_T2$0_0$0 == 0x00c9
                           0000C9   365 _C_T2	=	0x00c9
                           0000CA   366 G$TR2$0_0$0 == 0x00ca
                           0000CA   367 _TR2	=	0x00ca
                           0000CB   368 G$EXEN2$0_0$0 == 0x00cb
                           0000CB   369 _EXEN2	=	0x00cb
                           0000CC   370 G$TCLK$0_0$0 == 0x00cc
                           0000CC   371 _TCLK	=	0x00cc
                           0000CD   372 G$RCLK$0_0$0 == 0x00cd
                           0000CD   373 _RCLK	=	0x00cd
                           0000CE   374 G$EXF2$0_0$0 == 0x00ce
                           0000CE   375 _EXF2	=	0x00ce
                           0000CF   376 G$TF2$0_0$0 == 0x00cf
                           0000CF   377 _TF2	=	0x00cf
                           0000D0   378 G$P$0_0$0 == 0x00d0
                           0000D0   379 _P	=	0x00d0
                           0000D1   380 G$FL$0_0$0 == 0x00d1
                           0000D1   381 _FL	=	0x00d1
                           0000D2   382 G$OV$0_0$0 == 0x00d2
                           0000D2   383 _OV	=	0x00d2
                           0000D3   384 G$RS0$0_0$0 == 0x00d3
                           0000D3   385 _RS0	=	0x00d3
                           0000D4   386 G$RS1$0_0$0 == 0x00d4
                           0000D4   387 _RS1	=	0x00d4
                           0000D5   388 G$F0$0_0$0 == 0x00d5
                           0000D5   389 _F0	=	0x00d5
                           0000D6   390 G$AC$0_0$0 == 0x00d6
                           0000D6   391 _AC	=	0x00d6
                           0000D7   392 G$CY$0_0$0 == 0x00d7
                           0000D7   393 _CY	=	0x00d7
                                    394 ;--------------------------------------------------------
                                    395 ; overlayable register banks
                                    396 ;--------------------------------------------------------
                                    397 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        398 	.ds 8
                                    399 ;--------------------------------------------------------
                                    400 ; internal ram data
                                    401 ;--------------------------------------------------------
                                    402 	.area DSEG    (DATA)
                           000000   403 G$cont$0_0$0==.
      000008                        404 _cont::
      000008                        405 	.ds 2
                           000002   406 Lmain.main$bcdResult$2_0$5==.
      00000A                        407 _main_bcdResult_131072_5:
      00000A                        408 	.ds 2
                                    409 ;--------------------------------------------------------
                                    410 ; overlayable items in internal ram
                                    411 ;--------------------------------------------------------
                                    412 ;--------------------------------------------------------
                                    413 ; Stack segment in internal ram
                                    414 ;--------------------------------------------------------
                                    415 	.area SSEG
      00000E                        416 __start__stack:
      00000E                        417 	.ds	1
                                    418 
                                    419 ;--------------------------------------------------------
                                    420 ; indirectly addressable internal ram data
                                    421 ;--------------------------------------------------------
                                    422 	.area ISEG    (DATA)
                                    423 ;--------------------------------------------------------
                                    424 ; absolute internal ram data
                                    425 ;--------------------------------------------------------
                                    426 	.area IABS    (ABS,DATA)
                                    427 	.area IABS    (ABS,DATA)
                                    428 ;--------------------------------------------------------
                                    429 ; bit data
                                    430 ;--------------------------------------------------------
                                    431 	.area BSEG    (BIT)
                                    432 ;--------------------------------------------------------
                                    433 ; paged external ram data
                                    434 ;--------------------------------------------------------
                                    435 	.area PSEG    (PAG,XDATA)
                                    436 ;--------------------------------------------------------
                                    437 ; uninitialized external ram data
                                    438 ;--------------------------------------------------------
                                    439 	.area XSEG    (XDATA)
                                    440 ;--------------------------------------------------------
                                    441 ; absolute external ram data
                                    442 ;--------------------------------------------------------
                                    443 	.area XABS    (ABS,XDATA)
                                    444 ;--------------------------------------------------------
                                    445 ; initialized external ram data
                                    446 ;--------------------------------------------------------
                                    447 	.area XISEG   (XDATA)
                                    448 	.area HOME    (CODE)
                                    449 	.area GSINIT0 (CODE)
                                    450 	.area GSINIT1 (CODE)
                                    451 	.area GSINIT2 (CODE)
                                    452 	.area GSINIT3 (CODE)
                                    453 	.area GSINIT4 (CODE)
                                    454 	.area GSINIT5 (CODE)
                                    455 	.area GSINIT  (CODE)
                                    456 	.area GSFINAL (CODE)
                                    457 	.area CSEG    (CODE)
                                    458 ;--------------------------------------------------------
                                    459 ; interrupt vector
                                    460 ;--------------------------------------------------------
                                    461 	.area HOME    (CODE)
      000000                        462 __interrupt_vect:
      000000 02 00 19         [24]  463 	ljmp	__sdcc_gsinit_startup
      000003 02 00 7A         [24]  464 	ljmp	_int0
      000006                        465 	.ds	5
      00000B 32               [24]  466 	reti
      00000C                        467 	.ds	7
      000013 02 00 98         [24]  468 	ljmp	_int1
                                    469 ;--------------------------------------------------------
                                    470 ; global & static initialisations
                                    471 ;--------------------------------------------------------
                                    472 	.area HOME    (CODE)
                                    473 	.area GSINIT  (CODE)
                                    474 	.area GSFINAL (CODE)
                                    475 	.area GSINIT  (CODE)
                                    476 	.globl __sdcc_gsinit_startup
                                    477 	.globl __sdcc_program_startup
                                    478 	.globl __start__stack
                                    479 	.globl __mcs51_genXINIT
                                    480 	.globl __mcs51_genXRAMCLEAR
                                    481 	.globl __mcs51_genRAMCLEAR
                           000000   482 	C$main.c$10$1_0$4 ==.
                                    483 ;	../main.c:10: int cont = 0;
      000072 E4               [12]  484 	clr	a
      000073 F5 08            [12]  485 	mov	_cont,a
      000075 F5 09            [12]  486 	mov	(_cont + 1),a
                                    487 	.area GSFINAL (CODE)
      000077 02 00 16         [24]  488 	ljmp	__sdcc_program_startup
                                    489 ;--------------------------------------------------------
                                    490 ; Home
                                    491 ;--------------------------------------------------------
                                    492 	.area HOME    (CODE)
                                    493 	.area HOME    (CODE)
      000016                        494 __sdcc_program_startup:
      000016 02 00 B0         [24]  495 	ljmp	_main
                                    496 ;	return from main will return to caller
                                    497 ;--------------------------------------------------------
                                    498 ; code
                                    499 ;--------------------------------------------------------
                                    500 	.area CSEG    (CODE)
                                    501 ;------------------------------------------------------------
                                    502 ;Allocation info for local variables in function 'int0'
                                    503 ;------------------------------------------------------------
                           000000   504 	G$int0$0$0 ==.
                           000000   505 	C$main.c$13$0_0$1 ==.
                                    506 ;	../main.c:13: void int0()  __interrupt(0)
                                    507 ;	-----------------------------------------
                                    508 ;	 function int0
                                    509 ;	-----------------------------------------
      00007A                        510 _int0:
                           000007   511 	ar7 = 0x07
                           000006   512 	ar6 = 0x06
                           000005   513 	ar5 = 0x05
                           000004   514 	ar4 = 0x04
                           000003   515 	ar3 = 0x03
                           000002   516 	ar2 = 0x02
                           000001   517 	ar1 = 0x01
                           000000   518 	ar0 = 0x00
      00007A C0 E0            [24]  519 	push	acc
      00007C C0 D0            [24]  520 	push	psw
                           000004   521 	C$main.c$15$1_0$1 ==.
                                    522 ;	../main.c:15: if (cont < 20)
      00007E C3               [12]  523 	clr	c
      00007F E5 08            [12]  524 	mov	a,_cont
      000081 94 14            [12]  525 	subb	a,#0x14
      000083 E5 09            [12]  526 	mov	a,(_cont + 1)
      000085 64 80            [12]  527 	xrl	a,#0x80
      000087 94 80            [12]  528 	subb	a,#0x80
      000089 50 08            [24]  529 	jnc	00103$
                           000011   530 	C$main.c$16$1_0$1 ==.
                                    531 ;	../main.c:16: cont++;
      00008B 05 08            [12]  532 	inc	_cont
      00008D E4               [12]  533 	clr	a
      00008E B5 08 02         [24]  534 	cjne	a,_cont,00110$
      000091 05 09            [12]  535 	inc	(_cont + 1)
      000093                        536 00110$:
      000093                        537 00103$:
                           000019   538 	C$main.c$17$1_0$1 ==.
                                    539 ;	../main.c:17: }
      000093 D0 D0            [24]  540 	pop	psw
      000095 D0 E0            [24]  541 	pop	acc
                           00001D   542 	C$main.c$17$1_0$1 ==.
                           00001D   543 	XG$int0$0$0 ==.
      000097 32               [24]  544 	reti
                                    545 ;	eliminated unneeded mov psw,# (no regs used in bank)
                                    546 ;	eliminated unneeded push/pop dpl
                                    547 ;	eliminated unneeded push/pop dph
                                    548 ;	eliminated unneeded push/pop b
                                    549 ;------------------------------------------------------------
                                    550 ;Allocation info for local variables in function 'int1'
                                    551 ;------------------------------------------------------------
                           00001E   552 	G$int1$0$0 ==.
                           00001E   553 	C$main.c$19$1_0$2 ==.
                                    554 ;	../main.c:19: void int1()  __interrupt(2)
                                    555 ;	-----------------------------------------
                                    556 ;	 function int1
                                    557 ;	-----------------------------------------
      000098                        558 _int1:
      000098 C0 E0            [24]  559 	push	acc
      00009A C0 D0            [24]  560 	push	psw
                           000022   561 	C$main.c$21$1_0$2 ==.
                                    562 ;	../main.c:21: if (cont != 0)
      00009C E5 08            [12]  563 	mov	a,_cont
      00009E 45 09            [12]  564 	orl	a,(_cont + 1)
      0000A0 60 09            [24]  565 	jz	00103$
                           000028   566 	C$main.c$22$1_0$2 ==.
                                    567 ;	../main.c:22: cont--;
      0000A2 15 08            [12]  568 	dec	_cont
      0000A4 74 FF            [12]  569 	mov	a,#0xff
      0000A6 B5 08 02         [24]  570 	cjne	a,_cont,00110$
      0000A9 15 09            [12]  571 	dec	(_cont + 1)
      0000AB                        572 00110$:
      0000AB                        573 00103$:
                           000031   574 	C$main.c$23$1_0$2 ==.
                                    575 ;	../main.c:23: }
      0000AB D0 D0            [24]  576 	pop	psw
      0000AD D0 E0            [24]  577 	pop	acc
                           000035   578 	C$main.c$23$1_0$2 ==.
                           000035   579 	XG$int1$0$0 ==.
      0000AF 32               [24]  580 	reti
                                    581 ;	eliminated unneeded mov psw,# (no regs used in bank)
                                    582 ;	eliminated unneeded push/pop dpl
                                    583 ;	eliminated unneeded push/pop dph
                                    584 ;	eliminated unneeded push/pop b
                                    585 ;------------------------------------------------------------
                                    586 ;Allocation info for local variables in function 'main'
                                    587 ;------------------------------------------------------------
                                    588 ;binaryInput               Allocated to registers r6 r7 
                                    589 ;bcdResult                 Allocated with name '_main_bcdResult_131072_5'
                                    590 ;shift                     Allocated to registers r2 r3 
                                    591 ;------------------------------------------------------------
                           000036   592 	G$main$0$0 ==.
                           000036   593 	C$main.c$25$1_0$4 ==.
                                    594 ;	../main.c:25: void main(void)
                                    595 ;	-----------------------------------------
                                    596 ;	 function main
                                    597 ;	-----------------------------------------
      0000B0                        598 _main:
                           000036   599 	C$main.c$31$1_0$4 ==.
                                    600 ;	../main.c:31: EA = 1;
                                    601 ;	assignBit
      0000B0 D2 AF            [12]  602 	setb	_EA
                           000038   603 	C$main.c$33$1_0$4 ==.
                                    604 ;	../main.c:33: EX0 = 1;
                                    605 ;	assignBit
      0000B2 D2 A8            [12]  606 	setb	_EX0
                           00003A   607 	C$main.c$34$1_0$4 ==.
                                    608 ;	../main.c:34: EX1 = 1;
                                    609 ;	assignBit
      0000B4 D2 AA            [12]  610 	setb	_EX1
                           00003C   611 	C$main.c$37$1_0$4 ==.
                                    612 ;	../main.c:37: IT0 = 1;
                                    613 ;	assignBit
      0000B6 D2 88            [12]  614 	setb	_IT0
                           00003E   615 	C$main.c$38$1_0$4 ==.
                                    616 ;	../main.c:38: IT1 = 1;
                                    617 ;	assignBit
      0000B8 D2 8A            [12]  618 	setb	_IT1
                           000040   619 	C$main.c$40$1_0$4 ==.
                                    620 ;	../main.c:40: P2=0;    
      0000BA 75 A0 00         [24]  621 	mov	_P2,#0x00
                           000043   622 	C$main.c$42$1_0$4 ==.
                                    623 ;	../main.c:42: while (1)//Loop da aplica��o
      0000BD                        624 00111$:
                           000043   625 	C$main.c$44$3_0$5 ==.
                                    626 ;	../main.c:44: int binaryInput = cont;
      0000BD AE 08            [24]  627 	mov	r6,_cont
      0000BF AF 09            [24]  628 	mov	r7,(_cont + 1)
                           000047   629 	C$main.c$45$3_0$5 ==.
                                    630 ;	../main.c:45: int bcdResult = 0;
      0000C1 E4               [12]  631 	clr	a
      0000C2 F5 0A            [12]  632 	mov	_main_bcdResult_131072_5,a
      0000C4 F5 0B            [12]  633 	mov	(_main_bcdResult_131072_5 + 1),a
                           00004C   634 	C$main.c$46$3_0$5 ==.
                                    635 ;	../main.c:46: int shift = 0;
      0000C6 FA               [12]  636 	mov	r2,a
      0000C7 FB               [12]  637 	mov	r3,a
                           00004E   638 	C$main.c$47$2_0$5 ==.
                                    639 ;	../main.c:47: while (binaryInput > 0) {
      0000C8                        640 00101$:
      0000C8 C3               [12]  641 	clr	c
      0000C9 E4               [12]  642 	clr	a
      0000CA 9E               [12]  643 	subb	a,r6
      0000CB 74 80            [12]  644 	mov	a,#(0x00 ^ 0x80)
      0000CD 8F F0            [24]  645 	mov	b,r7
      0000CF 63 F0 80         [24]  646 	xrl	b,#0x80
      0000D2 95 F0            [12]  647 	subb	a,b
      0000D4 50 5D            [24]  648 	jnc	00103$
                           00005C   649 	C$main.c$48$1_0$4 ==.
                                    650 ;	../main.c:48: bcdResult |= (binaryInput % 10) << (shift++ << 2);
      0000D6 75 0C 0A         [24]  651 	mov	__modsint_PARM_2,#0x0a
      0000D9 75 0D 00         [24]  652 	mov	(__modsint_PARM_2 + 1),#0x00
      0000DC 8E 82            [24]  653 	mov	dpl,r6
      0000DE 8F 83            [24]  654 	mov	dph,r7
      0000E0 C0 07            [24]  655 	push	ar7
      0000E2 C0 06            [24]  656 	push	ar6
      0000E4 C0 03            [24]  657 	push	ar3
      0000E6 C0 02            [24]  658 	push	ar2
      0000E8 12 01 D8         [24]  659 	lcall	__modsint
      0000EB A8 82            [24]  660 	mov	r0,dpl
      0000ED A9 83            [24]  661 	mov	r1,dph
      0000EF D0 02            [24]  662 	pop	ar2
      0000F1 D0 03            [24]  663 	pop	ar3
      0000F3 D0 06            [24]  664 	pop	ar6
      0000F5 D0 07            [24]  665 	pop	ar7
      0000F7 8A 04            [24]  666 	mov	ar4,r2
      0000F9 0A               [12]  667 	inc	r2
      0000FA BA 00 01         [24]  668 	cjne	r2,#0x00,00136$
      0000FD 0B               [12]  669 	inc	r3
      0000FE                        670 00136$:
      0000FE EC               [12]  671 	mov	a,r4
      0000FF 2C               [12]  672 	add	a,r4
      000100 25 E0            [12]  673 	add	a,acc
      000102 FC               [12]  674 	mov	r4,a
      000103 8C F0            [24]  675 	mov	b,r4
      000105 05 F0            [12]  676 	inc	b
      000107 80 06            [24]  677 	sjmp	00138$
      000109                        678 00137$:
      000109 E8               [12]  679 	mov	a,r0
      00010A 28               [12]  680 	add	a,r0
      00010B F8               [12]  681 	mov	r0,a
      00010C E9               [12]  682 	mov	a,r1
      00010D 33               [12]  683 	rlc	a
      00010E F9               [12]  684 	mov	r1,a
      00010F                        685 00138$:
      00010F D5 F0 F7         [24]  686 	djnz	b,00137$
      000112 E8               [12]  687 	mov	a,r0
      000113 42 0A            [12]  688 	orl	_main_bcdResult_131072_5,a
      000115 E9               [12]  689 	mov	a,r1
      000116 42 0B            [12]  690 	orl	(_main_bcdResult_131072_5 + 1),a
                           00009E   691 	C$main.c$49$1_0$4 ==.
                                    692 ;	../main.c:49: binaryInput /= 10;
      000118 75 0C 0A         [24]  693 	mov	__divsint_PARM_2,#0x0a
      00011B 75 0D 00         [24]  694 	mov	(__divsint_PARM_2 + 1),#0x00
      00011E 8E 82            [24]  695 	mov	dpl,r6
      000120 8F 83            [24]  696 	mov	dph,r7
      000122 C0 03            [24]  697 	push	ar3
      000124 C0 02            [24]  698 	push	ar2
      000126 12 02 0E         [24]  699 	lcall	__divsint
      000129 AE 82            [24]  700 	mov	r6,dpl
      00012B AF 83            [24]  701 	mov	r7,dph
      00012D D0 02            [24]  702 	pop	ar2
      00012F D0 03            [24]  703 	pop	ar3
      000131 80 95            [24]  704 	sjmp	00101$
      000133                        705 00103$:
                           0000B9   706 	C$main.c$51$2_0$5 ==.
                                    707 ;	../main.c:51: P2 = bcdResult; 
      000133 85 0A A0         [24]  708 	mov	_P2,_main_bcdResult_131072_5
                           0000BC   709 	C$main.c$53$2_0$5 ==.
                                    710 ;	../main.c:53: P3 = 0x00;
      000136 75 B0 00         [24]  711 	mov	_P3,#0x00
                           0000BF   712 	C$main.c$54$2_0$5 ==.
                                    713 ;	../main.c:54: if(cont == 0)
      000139 E5 08            [12]  714 	mov	a,_cont
      00013B 45 09            [12]  715 	orl	a,(_cont + 1)
      00013D 70 07            [24]  716 	jnz	00108$
                           0000C5   717 	C$main.c$56$3_0$7 ==.
                                    718 ;	../main.c:56: P3_0 = 1;
                                    719 ;	assignBit
      00013F D2 B0            [12]  720 	setb	_P3_0
                           0000C7   721 	C$main.c$57$3_0$7 ==.
                                    722 ;	../main.c:57: P3_1 = 0;
                                    723 ;	assignBit
      000141 C2 B1            [12]  724 	clr	_P3_1
      000143 02 00 BD         [24]  725 	ljmp	00111$
      000146                        726 00108$:
                           0000CC   727 	C$main.c$59$2_0$5 ==.
                                    728 ;	../main.c:59: else if(cont >= 20)
      000146 C3               [12]  729 	clr	c
      000147 E5 08            [12]  730 	mov	a,_cont
      000149 94 14            [12]  731 	subb	a,#0x14
      00014B E5 09            [12]  732 	mov	a,(_cont + 1)
      00014D 64 80            [12]  733 	xrl	a,#0x80
      00014F 94 80            [12]  734 	subb	a,#0x80
      000151 40 07            [24]  735 	jc	00105$
                           0000D9   736 	C$main.c$61$3_0$8 ==.
                                    737 ;	../main.c:61: P3_1 = 1;
                                    738 ;	assignBit
      000153 D2 B1            [12]  739 	setb	_P3_1
                           0000DB   740 	C$main.c$62$3_0$8 ==.
                                    741 ;	../main.c:62: P3_0 = 0;
                                    742 ;	assignBit
      000155 C2 B0            [12]  743 	clr	_P3_0
      000157 02 00 BD         [24]  744 	ljmp	00111$
      00015A                        745 00105$:
                           0000E0   746 	C$main.c$66$3_0$9 ==.
                                    747 ;	../main.c:66: P3_0 = 1;
                                    748 ;	assignBit
      00015A D2 B0            [12]  749 	setb	_P3_0
                           0000E2   750 	C$main.c$67$3_0$9 ==.
                                    751 ;	../main.c:67: P3_1 = 0;
                                    752 ;	assignBit
      00015C C2 B1            [12]  753 	clr	_P3_1
      00015E 02 00 BD         [24]  754 	ljmp	00111$
                           0000E7   755 	C$main.c$71$1_0$4 ==.
                                    756 ;	../main.c:71: }
                           0000E7   757 	C$main.c$71$1_0$4 ==.
                           0000E7   758 	XG$main$0$0 ==.
      000161 22               [24]  759 	ret
                                    760 	.area CSEG    (CODE)
                                    761 	.area CONST   (CODE)
                                    762 	.area XINIT   (CODE)
                                    763 	.area CABS    (ABS,CODE)
